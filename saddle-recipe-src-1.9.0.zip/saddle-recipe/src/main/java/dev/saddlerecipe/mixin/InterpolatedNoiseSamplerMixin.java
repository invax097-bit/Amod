package dev.saddlerecipe.mixin;

import dev.saddlerecipe.FarLands;
import net.minecraft.util.math.noise.InterpolatedNoiseSampler;
import net.minecraft.world.gen.densityfunction.DensityFunction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Далёкие земли: искажаем координаты и усиливаем базовый шум рельефа с расстоянием. */
@Mixin(InterpolatedNoiseSampler.class)
public abstract class InterpolatedNoiseSamplerMixin {
    @ModifyVariable(method = "sample", at = @At("HEAD"), argsOnly = true)
    private DensityFunction.NoisePos saddlerecipe$distort(DensityFunction.NoisePos pos) {
        return FarLands.distort(pos);
    }

    @Inject(method = "sample", at = @At("RETURN"), cancellable = true)
    private void saddlerecipe$amplify(DensityFunction.NoisePos pos, CallbackInfoReturnable<Double> cir) {
        DensityFunction.NoisePos o = FarLands.original(pos);
        int x = o.blockX(), z = o.blockZ();
        double l = FarLands.liminal(x, z);
        if (l <= 0.0) return;
        double v = cir.getReturnValueD() * FarLands.gain(x, z);
        v += FarLands.structure(x, o.blockY(), z) * FarLands.STRUCTURE_AMP * l;
        cir.setReturnValue(v);
    }
}
