package dev.saddlerecipe.mixin;

import dev.saddlerecipe.FarLands;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import net.minecraft.world.StructureWorldAccess;
import net.minecraft.world.gen.chunk.ChunkGenerator;
import net.minecraft.world.gen.feature.ConfiguredFeature;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.PlacedFeature;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Set;

/** Далёкие земли: чем дальше от центра, тем меньше растений (деревья, цветы, трава, водоросли...). */
@Mixin(PlacedFeature.class)
public abstract class PlacedFeatureMixin {
    private static final Set<String> VEGETATION = Set.of(
            "tree", "flower", "no_bonemeal_flower", "random_patch", "kelp", "seagrass", "bamboo",
            "vines", "huge_red_mushroom", "huge_brown_mushroom", "huge_fungus", "sea_pickle",
            "block_column", "vegetation_patch", "waterlogged_vegetation_patch", "multiface_growth",
            "simple_block", "random_selector", "simple_random_selector", "random_boolean_selector",
            "weeping_vines", "twisting_vines", "nether_forest_vegetation");

    @Shadow public abstract RegistryEntry<ConfiguredFeature<?, ?>> feature();

    @Inject(method = "generateUnregistered", at = @At("HEAD"), cancellable = true)
    private void saddlerecipe$noPlants(StructureWorldAccess world, ChunkGenerator generator, Random random,
                                      BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
        if (!FarLands.removeVegetation(pos.getX(), pos.getZ())) return;
        if (world.toServerWorld().getRegistryKey() != World.OVERWORLD) return;
        Feature<?> type = this.feature().value().feature();
        Identifier id = Registries.FEATURE.getId(type);
        if (id != null && VEGETATION.contains(id.getPath())) cir.setReturnValue(false);
    }
}
