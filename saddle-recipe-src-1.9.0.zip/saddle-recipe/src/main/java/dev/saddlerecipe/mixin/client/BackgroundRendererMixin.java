package dev.saddlerecipe.mixin.client;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.saddlerecipe.FarLands;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.CameraSubmersionType;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Далёкие земли: туман, который подступает ближе с расстоянием от центра. */
@Mixin(BackgroundRenderer.class)
public abstract class BackgroundRendererMixin {
    @Inject(method = "applyFog", at = @At("TAIL"), require = 0)
    private static void saddlerecipe$liminalFog(Camera camera, BackgroundRenderer.FogType fogType,
                                                float viewDistance, boolean thickFog, float tickDelta,
                                                CallbackInfo ci) {
        if (fogType != BackgroundRenderer.FogType.FOG_TERRAIN) return;
        if (camera.getSubmersionType() != CameraSubmersionType.NONE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.world.getRegistryKey() != World.OVERWORLD) return;
        Vec3d pos = camera.getPos();
        double l = FarLands.liminal((int) pos.x, (int) pos.z);
        if (l <= 0.0) return;
        float end = (float) (viewDistance + (Math.min(viewDistance, 32.0f) - viewDistance) * l);
        RenderSystem.setShaderFogStart(end * 0.1f);
        RenderSystem.setShaderFogEnd(end);
    }
}
