package dev.saddlerecipe;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.world.World;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class SaddleRecipeMod implements ModInitializer {
    public static final String MOD_ID = "saddlerecipe";

    public static final Block COLORED_WATER_CAULDRON = Registry.register(
            Registries.BLOCK, new Identifier(MOD_ID, "colored_water_cauldron"),
            new ColoredWaterCauldronBlock(AbstractBlock.Settings.copy(Blocks.WATER_CAULDRON)));

    public static final BlockEntityType<ColoredCauldronBlockEntity> COLORED_CAULDRON_BE = Registry.register(
            Registries.BLOCK_ENTITY_TYPE, new Identifier(MOD_ID, "colored_water_cauldron"),
            FabricBlockEntityTypeBuilder.create(ColoredCauldronBlockEntity::new, COLORED_WATER_CAULDRON).build());

    public static final StatusEffect FIRE_AURA = Registry.register(
            Registries.STATUS_EFFECT, new Identifier(MOD_ID, "fire_aura"), new FireAuraEffect());

    @Override
    public void onInitialize() {
        // Flowers are mixed in only by dropping them into a water cauldron (see ItemEntityMixin).
        AmethystRails.register();
        Liminal.register();

        // Далёкие земли: чем дальше от центра, тем меньше мобов (игроки, предметы и боссы не затрагиваются).
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (!(entity instanceof MobEntity) || entity.hasCustomName()) return;
            if (world.getRegistryKey() != World.OVERWORLD) return;
            if (FarLands.removeMob(entity.getBlockX(), entity.getBlockZ(), entity.getUuid().hashCode())) {
                entity.discard();
            }
        });
    }
}
