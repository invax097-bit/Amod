package dev.saddlerecipe;

import net.minecraft.world.gen.densityfunction.DensityFunction;

/**
 * Далёкие земли: начиная с START блоков от (0, 0) генерация мира всё сильнее искажается.
 * Применяется к базовому 3D-шуму рельефа (см. InterpolatedNoiseSamplerMixin).
 */
public final class FarLands {
    /** С какого расстояния (в блоках) от центра мира начинается искажение. */
    public static final double START = 100.0;
    /** Чем меньше — тем быстрее нарастает усиление шума. */
    public static final double GAIN_RANGE = 24.0;
    /** Потолок усиления шума. */
    public static final double MAX_GAIN = 48.0;
    /** Через сколько блоков шаг "замораживания" координат растёт на 1 (стены/ступени). */
    public static final double STEP_RANGE = 20.0;
    public static final int MAX_STEP = 512;
    /** Через сколько блоков за START мир становится полностью пустым (без растений и мобов). */
    public static final double LIMINAL_RANGE = 250.0;

    /** Амплитуда "архитектурной" составляющей плотности при liminal == 1. */
    public static final double STRUCTURE_AMP = 40.0;

    private FarLands() {}

    /** Искажённая позиция; помнит исходную, чтобы строить чёткие формы по настоящим координатам. */
    public static final class Distorted implements DensityFunction.NoisePos {
        public final DensityFunction.NoisePos orig;
        private final int x, y, z;
        Distorted(DensityFunction.NoisePos orig, int x, int y, int z) {
            this.orig = orig; this.x = x; this.y = y; this.z = z;
        }
        @Override public int blockX() { return x; }
        @Override public int blockY() { return y; }
        @Override public int blockZ() { return z; }
    }

    public static DensityFunction.NoisePos original(DensityFunction.NoisePos pos) {
        return pos instanceof Distorted d ? d.orig : pos;
    }

    /**
     * Неестественные постройки из блоков: лестницы, коридоры, залы с колоннами, зиккураты, шахматные кубы.
     * Возвращает +1 (твёрдое) или -1 (пустота), 0 — если в этом регионе (64x64) построек нет.
     * Работает в ячейках шума 4x8x4 блока (плотность интерполируется между ними), поэтому формы крупные и со скосами.
     */
    public static int structure(int x, int y, int z) {
        int cx = Math.floorDiv(x, 4), cy = Math.floorDiv(y, 8), cz = Math.floorDiv(z, 4);
        int mode = (int) (hash01(Math.floorDiv(cx, 16) * 7919 + 13, Math.floorDiv(cz, 16) * 104729 + 29) * 8.0);
        boolean solid;
        switch (mode) {
            case 1 -> solid = Math.floorMod(cy, 3) * 2 <= Math.floorMod(cx, 6);          // лестницы вдоль X
            case 2 -> solid = Math.floorMod(cy, 3) * 2 <= Math.floorMod(cz, 6);          // лестницы вдоль Z
            case 3 -> {                                                                  // сетка коридоров и шахты
                boolean floor = Math.floorMod(cy, 3) == 0;
                boolean alongX = floor && Math.floorMod(cz, 4) == 0;
                boolean alongZ = floor && Math.floorMod(cx, 4) == 0;
                boolean shaft = Math.floorMod(cx, 4) == 0 && Math.floorMod(cz, 4) == 0;
                solid = !(alongX || alongZ || shaft);
            }
            case 4 -> solid = Math.floorMod(cy, 3) == 0                                  // залы: плиты и колонны
                    || (Math.floorMod(cx, 4) == 0 && Math.floorMod(cz, 4) == 0);
            case 5 -> {                                                                  // зиккураты
                int dist = Math.max(Math.abs(Math.floorMod(cx, 16) - 8), Math.abs(Math.floorMod(cz, 16) - 8));
                solid = cy <= 10 - dist;
            }
            case 6 -> solid = ((cx >> 1) + cy + (cz >> 1) & 1) == 0;                     // шахматные кубы
            default -> { return 0; }
        }
        return solid ? 1 : -1;
    }

    /** Расстояние за пределами START (0, если ближе). */
    public static double excess(int x, int z) {
        // быстрый выход без sqrt для всей "нормальной" зоны
        if ((double) x * x + (double) z * z <= START * START) return 0.0;
        double d = Math.sqrt((double) x * x + (double) z * z);
        return Math.max(0.0, d - START);
    }

    public static double gain(int x, int z) {
        double t = excess(x, z);
        if (t <= 0.0) return 1.0;
        return Math.min(MAX_GAIN, 1.0 + t / GAIN_RANGE);
    }

    private static int snap(int v, int step) {
        return step <= 1 ? v : Math.floorDiv(v, step) * step;
    }

    /** Искажённая позиция: координаты "слипаются" в крупные ступени, чем дальше — тем крупнее. */
    public static DensityFunction.NoisePos distort(DensityFunction.NoisePos pos) {
        double t = excess(pos.blockX(), pos.blockZ());
        if (t <= 0.0) return pos;
        int step = (int) Math.min(MAX_STEP, 1 + t / STEP_RANGE);
        // Небольшой "перекос" по осям, как у классических Далёких земель.
        final int x = snap(pos.blockX(), step);
        final int z = snap(pos.blockZ() + (int) (t / 3.0), Math.max(1, step / 2));
        final int y = snap(pos.blockY(), Math.max(1, step / 6));
        return new Distorted(pos, x, y, z);
    }

    /** 0 — обычный мир, 1 — полная пустота. Растёт с расстоянием от центра. */
    public static double liminal(int x, int z) {
        return Math.min(1.0, excess(x, z) / LIMINAL_RANGE);
    }

    /** Детерминированный псевдослучайный хэш в [0, 1). */
    public static double hash01(int a, int b) {
        long h = a * 341873128712L + b * 132897987541L;
        h ^= h >>> 29;
        h *= 0xBF58476D1CE4E5B9L;
        h ^= h >>> 32;
        return (h & 0xFFFFFF) / 16777216.0;
    }

    /** Убрать ли растительность в этой точке (вероятность растёт с расстоянием). */
    public static boolean removeVegetation(int x, int z) {
        double l = liminal(x, z);
        return l > 0.0 && hash01(x, z) < l;
    }

    /** Убрать ли моба с таким UUID-хэшем в этой точке. */
    public static boolean removeMob(int x, int z, int uuidHash) {
        double l = liminal(x, z);
        return l > 0.0 && ((uuidHash & 0xFFFF) / 65536.0) < l;
    }
}
