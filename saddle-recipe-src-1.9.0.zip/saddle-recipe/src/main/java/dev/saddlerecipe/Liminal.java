package dev.saddlerecipe;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.network.packet.s2c.play.GameStateChangeS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Атмосфера Далёких земель в духе Backrooms: гул, далёкие звуки "кого-то", пыль в воздухе,
 * тусклое безтеневое небо, редкие приступы темноты. Всё нарастает с расстоянием.
 */
public final class Liminal {
    private static final Set<UUID> GLOOMED = new HashSet<>();

    private Liminal() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(Liminal::tick);
    }

    private static void tick(MinecraftServer server) {
        int t = server.getTicks();
        if (t % 20 != 0) return;

        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            ServerWorld w = p.getServerWorld();
            double l = w.getRegistryKey() == World.OVERWORLD
                    ? FarLands.liminal(p.getBlockX(), p.getBlockZ()) : 0.0;

            // Тусклое, "выцветшее" небо без дождя (клиентский градиент грозы).
            if (t % 40 == 0) {
                if (l > 0.0) {
                    p.networkHandler.sendPacket(new GameStateChangeS2CPacket(
                            GameStateChangeS2CPacket.THUNDER_GRADIENT_CHANGED, (float) (0.25 + 0.65 * l)));
                    GLOOMED.add(p.getUuid());
                } else if (GLOOMED.remove(p.getUuid())) {
                    p.networkHandler.sendPacket(new GameStateChangeS2CPacket(
                            GameStateChangeS2CPacket.THUNDER_GRADIENT_CHANGED, w.getThunderGradient(1.0f)));
                }
            }
            if (l <= 0.05) continue;

            Random r = w.random;
            double x = p.getX(), y = p.getY(), z = p.getZ();

            // Низкий гул, как от люминесцентных ламп.
            if (t % 60 == 0) {
                w.playSound(null, x, y, z, SoundEvents.BLOCK_BEACON_AMBIENT, SoundCategory.AMBIENT,
                        (float) (0.1 + 0.5 * l), 0.5f);
            }

            // Пылинки, висящие в воздухе.
            if (l > 0.1) {
                w.spawnParticles(ParticleTypes.WHITE_ASH, x, y + 1.5, z, (int) (5 + 25 * l), 8, 3, 8, 0.01);
            }

            // Далёкие звуки: хлопнувшая дверь, чей-то голос. Никого нет.
            if (r.nextDouble() < 0.03 + 0.07 * l) {
                SoundEvent s;
                float pitch;
                switch (r.nextInt(3)) {
                    case 0 -> { s = SoundEvents.BLOCK_IRON_DOOR_CLOSE; pitch = 0.7f; }
                    case 1 -> { s = SoundEvents.BLOCK_WOODEN_DOOR_CLOSE; pitch = 0.6f; }
                    default -> { s = SoundEvents.ENTITY_VILLAGER_AMBIENT; pitch = 0.5f; }
                }
                double a = r.nextDouble() * Math.PI * 2;
                double d = 20 + r.nextDouble() * 20;
                w.playSound(null, x + Math.cos(a) * d, y, z + Math.sin(a) * d, s, SoundCategory.AMBIENT, 2.0f, pitch);
            }

            // Дальше всего — сердцебиение и вспышки темноты.
            if (l > 0.6 && r.nextDouble() < 0.05) {
                w.playSound(null, x, y, z, SoundEvents.ENTITY_WARDEN_HEARTBEAT, SoundCategory.AMBIENT, 1.0f, 0.9f);
            }
            if (l > 0.5 && t % 200 == 0 && r.nextDouble() < 0.4) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 140, 0, true, false, false));
            }
        }
    }
}
