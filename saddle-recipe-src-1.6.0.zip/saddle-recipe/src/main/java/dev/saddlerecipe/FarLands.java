package dev.saddlerecipe;

import net.minecraft.world.gen.densityfunction.DensityFunction;

/**
 * Далёкие земли: начиная с START блоков от (0, 0) генерация мира всё сильнее искажается.
 * Применяется к базовому 3D-шуму рельефа (см. InterpolatedNoiseSamplerMixin).
 */
public final class FarLands {
    /** С какого расстояния (в блоках) от центра мира начинается искажение. */
    public static final double START = 100.0;
    /** Чем меньше — тем быстрее нарастает усиление шума. */
    public static final double GAIN_RANGE = 32.0;
    /** Потолок усиления шума. */
    public static final double MAX_GAIN = 64.0;
    /** Через сколько блоков шаг "замораживания" координат растёт на 1 (стены/ступени). */
    public static final double STEP_RANGE = 48.0;
    public static final int MAX_STEP = 256;

    private FarLands() {}

    /** Расстояние за пределами START (0, если ближе). */
    public static double excess(int x, int z) {
        double d = Math.sqrt((double) x * x + (double) z * z);
        return Math.max(0.0, d - START);
    }

    public static double gain(int x, int z) {
        double t = excess(x, z);
        if (t <= 0.0) return 1.0;
        return Math.min(MAX_GAIN, 1.0 + t / GAIN_RANGE);
    }

    private static int snap(int v, int step) {
        return step <= 1 ? v : Math.floorDiv(v, step) * step;
    }

    /** Искажённая позиция: координаты "слипаются" в крупные ступени, чем дальше — тем крупнее. */
    public static DensityFunction.NoisePos distort(DensityFunction.NoisePos pos) {
        double t = excess(pos.blockX(), pos.blockZ());
        if (t <= 0.0) return pos;
        int step = (int) Math.min(MAX_STEP, 1 + t / STEP_RANGE);
        // Небольшой "перекос" по осям, как у классических Далёких земель.
        final int x = snap(pos.blockX(), step);
        final int z = snap(pos.blockZ() + (int) (t / 8.0), Math.max(1, step / 2));
        final int y = pos.blockY();
        return new DensityFunction.NoisePos() {
            @Override public int blockX() { return x; }
            @Override public int blockY() { return y; }
            @Override public int blockZ() { return z; }
        };
    }
}
