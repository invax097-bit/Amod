package dev.saddlerecipe.mixin;

import dev.saddlerecipe.FarLands;
import net.minecraft.util.math.noise.InterpolatedNoiseSampler;
import net.minecraft.world.gen.densityfunction.DensityFunction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Далёкие земли: искажаем координаты и усиливаем базовый шум рельефа с расстоянием. */
@Mixin(InterpolatedNoiseSampler.class)
public abstract class InterpolatedNoiseSamplerMixin {
    @ModifyVariable(method = "sample", at = @At("HEAD"), argsOnly = true)
    private DensityFunction.NoisePos saddlerecipe$distort(DensityFunction.NoisePos pos) {
        return FarLands.distort(pos);
    }

    @Inject(method = "sample", at = @At("RETURN"), cancellable = true)
    private void saddlerecipe$amplify(DensityFunction.NoisePos pos, CallbackInfoReturnable<Double> cir) {
        double gain = FarLands.gain(pos.blockX(), pos.blockZ());
        if (gain != 1.0) cir.setReturnValue(cir.getReturnValueD() * gain);
    }
}
