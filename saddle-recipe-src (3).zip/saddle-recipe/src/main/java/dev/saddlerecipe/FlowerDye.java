package dev.saddlerecipe;

import java.util.HashMap;
import java.util.Map;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.LeveledCauldronBlock;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.DyeColor;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public final class FlowerDye {
    private static final Map<Item, DyeColor> COLORS = new HashMap<>();

    static {
        COLORS.put(Items.POPPY, DyeColor.RED);
        COLORS.put(Items.DANDELION, DyeColor.YELLOW);
        COLORS.put(Items.BLUE_ORCHID, DyeColor.LIGHT_BLUE);
        COLORS.put(Items.ALLIUM, DyeColor.MAGENTA);
        COLORS.put(Items.AZURE_BLUET, DyeColor.LIGHT_GRAY);
        COLORS.put(Items.RED_TULIP, DyeColor.RED);
        COLORS.put(Items.ORANGE_TULIP, DyeColor.ORANGE);
        COLORS.put(Items.WHITE_TULIP, DyeColor.WHITE);
        COLORS.put(Items.PINK_TULIP, DyeColor.PINK);
        COLORS.put(Items.OXEYE_DAISY, DyeColor.WHITE);
        COLORS.put(Items.CORNFLOWER, DyeColor.BLUE);
        COLORS.put(Items.LILY_OF_THE_VALLEY, DyeColor.WHITE);
        COLORS.put(Items.WITHER_ROSE, DyeColor.BLACK);
        COLORS.put(Items.TORCHFLOWER, DyeColor.ORANGE);
        COLORS.put(Items.PITCHER_PLANT, DyeColor.CYAN);
        COLORS.put(Items.SUNFLOWER, DyeColor.YELLOW);
        COLORS.put(Items.LILAC, DyeColor.MAGENTA);
        COLORS.put(Items.ROSE_BUSH, DyeColor.RED);
        COLORS.put(Items.PEONY, DyeColor.PINK);
    }

    private FlowerDye() {}

    public static boolean isFlower(ItemStack stack) {
        return stack.isIn(ItemTags.SMALL_FLOWERS) || stack.isIn(ItemTags.TALL_FLOWERS);
    }

    public static boolean isWaterCauldron(BlockState state) {
        return state.isOf(Blocks.WATER_CAULDRON) || state.isOf(SaddleRecipeMod.COLORED_WATER_CAULDRON);
    }

    public static DyeColor colorOf(ItemStack stack) {
        DyeColor known = COLORS.get(stack.getItem());
        if (known != null) return known;
        // Modded / unknown flower: stable colour derived from its id.
        int h = Registries.ITEM.getId(stack.getItem()).hashCode();
        return DyeColor.byId(Math.floorMod(h, 16));
    }

    /** Would this flower change the water in this cauldron state? */
    public static boolean canDye(BlockState state, ItemStack flower) {
        if (!isFlower(flower) || !isWaterCauldron(state)) return false;
        return !(state.isOf(SaddleRecipeMod.COLORED_WATER_CAULDRON)
                && state.get(ColoredWaterCauldronBlock.COLOR) == colorOf(flower));
    }

    /** Dyes the cauldron at pos. Does NOT consume the flower. Returns true if the water changed. */
    public static boolean dye(World world, BlockPos pos, ItemStack flower) {
        BlockState state = world.getBlockState(pos);
        if (!canDye(state, flower)) return false;

        DyeColor color = colorOf(flower);
        world.setBlockState(pos, SaddleRecipeMod.COLORED_WATER_CAULDRON.getDefaultState()
                .with(LeveledCauldronBlock.LEVEL, state.get(LeveledCauldronBlock.LEVEL))
                .with(ColoredWaterCauldronBlock.COLOR, color));

        world.playSound(null, pos, SoundEvents.ENTITY_GENERIC_SPLASH, SoundCategory.BLOCKS, 0.4f, 1.2f);
        if (world instanceof ServerWorld sw) {
            sw.spawnParticles(ParticleTypes.SPLASH, pos.getX() + 0.5, pos.getY() + 0.9, pos.getZ() + 0.5,
                    8, 0.2, 0.05, 0.2, 0.0);
        }
        return true;
    }
}
