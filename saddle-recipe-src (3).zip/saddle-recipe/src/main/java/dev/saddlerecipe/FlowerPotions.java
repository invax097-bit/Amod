package dev.saddlerecipe;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.block.BlockState;
import net.minecraft.block.LeveledCauldronBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsage;
import net.minecraft.item.Items;
import net.minecraft.potion.PotionUtil;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.DyeColor;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;

/** Weak, short potions: one per cauldron colour. */
public final class FlowerPotions {
    /** 12 seconds. */
    public static final int DURATION = 12 * 20;

    private static final Map<DyeColor, StatusEffect> EFFECTS = new EnumMap<>(DyeColor.class);

    static {
        EFFECTS.put(DyeColor.WHITE, StatusEffects.SLOW_FALLING);
        EFFECTS.put(DyeColor.ORANGE, StatusEffects.FIRE_RESISTANCE);
        EFFECTS.put(DyeColor.MAGENTA, StatusEffects.JUMP_BOOST);
        EFFECTS.put(DyeColor.LIGHT_BLUE, StatusEffects.SPEED);
        EFFECTS.put(DyeColor.YELLOW, StatusEffects.HASTE);
        EFFECTS.put(DyeColor.LIME, StatusEffects.REGENERATION);
        EFFECTS.put(DyeColor.PINK, StatusEffects.ABSORPTION);
        EFFECTS.put(DyeColor.GRAY, StatusEffects.RESISTANCE);
        EFFECTS.put(DyeColor.LIGHT_GRAY, StatusEffects.INVISIBILITY);
        EFFECTS.put(DyeColor.CYAN, StatusEffects.WATER_BREATHING);
        EFFECTS.put(DyeColor.PURPLE, StatusEffects.NIGHT_VISION);
        EFFECTS.put(DyeColor.BLUE, StatusEffects.DOLPHINS_GRACE);
        EFFECTS.put(DyeColor.BROWN, StatusEffects.HEALTH_BOOST);
        EFFECTS.put(DyeColor.GREEN, StatusEffects.LUCK);
        EFFECTS.put(DyeColor.RED, StatusEffects.STRENGTH);
        EFFECTS.put(DyeColor.BLACK, StatusEffects.GLOWING);
    }

    private FlowerPotions() {}

    public static ItemStack create(DyeColor color) {
        ItemStack stack = new ItemStack(Items.POTION);
        PotionUtil.setCustomPotionEffects(stack, List.of(new StatusEffectInstance(EFFECTS.get(color), DURATION, 0)));
        stack.getOrCreateNbt().putInt("CustomPotionColor", color.getFireworkColor());
        stack.setCustomName(Text.translatable("item.saddlerecipe.flower_potion." + color.getName())
                .styled(s -> s.withItalic(false)));
        return stack;
    }

    /** CauldronBehavior for an empty glass bottle used on a coloured cauldron. */
    public static ActionResult fillBottle(BlockState state, World world, BlockPos pos, PlayerEntity player,
                                          Hand hand, ItemStack stack) {
        if (!world.isClient) {
            ItemStack potion = create(state.get(ColoredWaterCauldronBlock.COLOR));
            player.setStackInHand(hand, ItemUsage.exchangeStack(stack, player, potion));
            player.incrementStat(Stats.USE_CAULDRON);
            player.incrementStat(Stats.USED.getOrCreateStat(stack.getItem()));
            LeveledCauldronBlock.decrementFluidLevel(state, world, pos);
            world.playSound(null, pos, SoundEvents.ITEM_BOTTLE_FILL, SoundCategory.BLOCKS, 1.0f, 1.0f);
            world.emitGameEvent(null, GameEvent.FLUID_PICKUP, pos);
        }
        return ActionResult.success(world.isClient);
    }
}
