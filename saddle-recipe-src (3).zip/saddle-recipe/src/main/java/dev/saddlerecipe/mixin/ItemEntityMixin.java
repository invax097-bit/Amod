package dev.saddlerecipe.mixin;

import dev.saddlerecipe.FlowerDye;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemEntity.class)
public abstract class ItemEntityMixin {
    @Inject(method = "tick", at = @At("HEAD"))
    private void saddlerecipe$dyeCauldron(CallbackInfo ci) {
        ItemEntity self = (ItemEntity) (Object) this;
        World world = self.getWorld();
        if (world.isClient || self.age % 2 != 0) return;

        ItemStack stack = self.getStack();
        if (stack.isEmpty() || !FlowerDye.isFlower(stack)) return;

        // Consume one flower only when the colour actually changes, so a dropped stack isn't eaten whole.
        if (FlowerDye.dye(world, self.getBlockPos(), stack)) {
            stack.decrement(1);
            if (stack.isEmpty()) self.discard();
        }
    }
}
