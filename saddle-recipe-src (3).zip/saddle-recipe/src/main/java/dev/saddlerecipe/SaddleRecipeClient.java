package dev.saddlerecipe;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.minecraft.client.render.RenderLayer;

public class SaddleRecipeClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BlockRenderLayerMap.INSTANCE.putBlock(SaddleRecipeMod.COLORED_WATER_CAULDRON, RenderLayer.getCutout());
        // The vanilla water_cauldron_* models tint the water surface (tintindex 0).
        ColorProviderRegistry.BLOCK.register(
                (state, world, pos, tintIndex) -> state.get(ColoredWaterCauldronBlock.COLOR).getFireworkColor(),
                SaddleRecipeMod.COLORED_WATER_CAULDRON);
    }
}
