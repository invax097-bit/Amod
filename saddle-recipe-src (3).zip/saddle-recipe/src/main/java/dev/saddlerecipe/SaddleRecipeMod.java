package dev.saddlerecipe;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;

public class SaddleRecipeMod implements ModInitializer {
    public static final String MOD_ID = "saddlerecipe";

    public static final Block COLORED_WATER_CAULDRON = Registry.register(
            Registries.BLOCK, new Identifier(MOD_ID, "colored_water_cauldron"),
            new ColoredWaterCauldronBlock(AbstractBlock.Settings.copy(Blocks.WATER_CAULDRON)));

    @Override
    public void onInitialize() {
        // Right-click a water cauldron with a flower.
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            ItemStack stack = player.getStackInHand(hand);
            if (player.isSpectator()) return ActionResult.PASS;
            if (!FlowerDye.canDye(world.getBlockState(hit.getBlockPos()), stack)) return ActionResult.PASS;
            if (!world.isClient) {
                FlowerDye.dye(world, hit.getBlockPos(), stack);
                if (!player.getAbilities().creativeMode) stack.decrement(1);
            }
            return ActionResult.SUCCESS;
        });
    }
}
