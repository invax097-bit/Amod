package dev.saddlerecipe;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.LeveledCauldronBlock;
import net.minecraft.block.cauldron.CauldronBehavior;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.util.DyeColor;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;
import net.minecraft.world.biome.Biome;

/** Water cauldron that remembers a dye colour (stored in the block state, no block entity). */
public class ColoredWaterCauldronBlock extends LeveledCauldronBlock {
    public static final EnumProperty<DyeColor> COLOR = EnumProperty.of("color", DyeColor.class);

    public ColoredWaterCauldronBlock(AbstractBlock.Settings settings) {
        super(settings, precipitation -> precipitation == Biome.Precipitation.RAIN,
                CauldronBehavior.WATER_CAULDRON_BEHAVIOR);
        setDefaultState(getDefaultState().with(LEVEL, 1).with(COLOR, DyeColor.WHITE));
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        super.appendProperties(builder);
        builder.add(COLOR);
    }

    @Override
    public ItemStack getPickStack(BlockView world, BlockPos pos, BlockState state) {
        return new ItemStack(Items.CAULDRON);
    }
}
