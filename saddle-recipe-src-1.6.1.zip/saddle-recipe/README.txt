Сборка в один шаг (нужен JDK 17+ и интернет):
  Windows:   gradlew.bat build
  Linux/Mac: ./gradlew build
Готовый мод: build/libs/saddle-recipe-1.6.1.jar  (Fabric 1.20.1 + Fabric API)
Без установки Java: залей папку на GitHub, вкладка Actions -> build -> скачай артефакт saddle-recipe-jar.
