package dev.saddlerecipe;

/** Реализуется миксином в AbstractMinecartEntity: состояние "вагонетка в прыжке". */
public interface AmethystJumper {
    boolean amethyst$isJumping();
    void amethyst$launch(int minAirTicks);
}
