package dev.saddlerecipe;

import java.util.function.Supplier;

import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.DyeColor;

/** One ingredient of a cauldron mix: a water tint plus the (weak) effect it gives. */
public enum FlowerMix {
    WHITE(DyeColor.WHITE, () -> StatusEffects.SLOW_FALLING),
    ORANGE(DyeColor.ORANGE, () -> StatusEffects.FIRE_RESISTANCE),
    MAGENTA(DyeColor.MAGENTA, () -> StatusEffects.JUMP_BOOST),
    LIGHT_BLUE(DyeColor.LIGHT_BLUE, () -> StatusEffects.SPEED),
    YELLOW(DyeColor.YELLOW, () -> StatusEffects.HASTE),
    LIME(DyeColor.LIME, () -> StatusEffects.REGENERATION),
    PINK(DyeColor.PINK, () -> StatusEffects.ABSORPTION),
    GRAY(DyeColor.GRAY, () -> StatusEffects.RESISTANCE),
    LIGHT_GRAY(DyeColor.LIGHT_GRAY, () -> StatusEffects.INVISIBILITY),
    CYAN(DyeColor.CYAN, () -> StatusEffects.WATER_BREATHING),
    PURPLE(DyeColor.PURPLE, () -> StatusEffects.NIGHT_VISION),
    BLUE(DyeColor.BLUE, () -> StatusEffects.DOLPHINS_GRACE),
    BROWN(DyeColor.BROWN, () -> StatusEffects.HEALTH_BOOST),
    GREEN(DyeColor.GREEN, () -> StatusEffects.LUCK),
    RED(DyeColor.RED, () -> StatusEffects.STRENGTH),
    BLACK(DyeColor.BLACK, () -> StatusEffects.GLOWING),
    /** Torchflower: its own ingredient, gives Ignition (not Fire Resistance). */
    TORCHFLOWER(0xFF7A1A, () -> SaddleRecipeMod.FIRE_AURA);

    /** How many "plain colour" ingredients exist (everything before TORCHFLOWER). */
    public static final int PLAIN_COUNT = 16;

    private final int rgb;
    private final Supplier<StatusEffect> effect;

    FlowerMix(DyeColor color, Supplier<StatusEffect> effect) {
        this(color.getFireworkColor(), effect);
    }

    FlowerMix(int rgb, Supplier<StatusEffect> effect) {
        this.rgb = rgb;
        this.effect = effect;
    }

    public int rgb() { return rgb; }
    public StatusEffect effect() { return effect.get(); }
    /** Lang-key suffix, e.g. "light_blue". */
    public String key() { return name().toLowerCase(); }
}
