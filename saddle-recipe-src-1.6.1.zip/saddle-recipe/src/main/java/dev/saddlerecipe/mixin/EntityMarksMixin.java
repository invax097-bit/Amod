package dev.saddlerecipe.mixin;

import dev.saddlerecipe.BlockMarks;
import dev.saddlerecipe.MarkedEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.MovementType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Слизь (отскок), мёд (замедление, меньше урона от падения). Все инъекции require=0: не роняют игру при несовпадении. */
@Mixin(Entity.class)
public abstract class EntityMarksMixin implements MarkedEntity {
    @Unique private int saddlerecipe$props;

    @Override public int saddlerecipe$getProps() { return saddlerecipe$props; }
    @Override public void saddlerecipe$setProps(int props) { saddlerecipe$props = props; }

    @Inject(method = "writeNbt", at = @At("RETURN"), require = 0)
    private void saddlerecipe$save(NbtCompound nbt, CallbackInfoReturnable<NbtCompound> cir) {
        if (saddlerecipe$props != 0) cir.getReturnValue().putInt("SaddleMarks", saddlerecipe$props);
    }

    @Inject(method = "readNbt", at = @At("RETURN"), require = 0)
    private void saddlerecipe$load(NbtCompound nbt, CallbackInfo ci) {
        saddlerecipe$props = nbt.getInt("SaddleMarks");
    }

    @Unique private double saddlerecipe$bounce = Double.NaN;

    @Inject(method = "fall", at = @At("HEAD"), require = 0)
    private void saddlerecipe$landOnMarked(double heightDifference, boolean onGround, BlockState state,
                                           BlockPos landedPosition, CallbackInfo ci) {
        if (!onGround) return;
        Entity self = (Entity) (Object) this;
        int p = BlockMarks.get(self.getWorld(), landedPosition) | saddlerecipe$props;
        if (p == 0) return;
        if ((p & BlockMarks.SLIME) != 0 && !self.isSneaking()) {
            double vy = self.getVelocity().y;
            self.fallDistance = 0.0F;
            if (vy < -0.1) saddlerecipe$bounce = -vy * (self instanceof LivingEntity ? 1.0 : 0.8);
        } else if ((p & BlockMarks.HONEY) != 0) {
            self.fallDistance *= 0.2F;
        }
    }

    // Ванильный onEntityLand обнуляет скорость по Y, поэтому прыжок применяем после move().
    @Inject(method = "move", at = @At("RETURN"), require = 0)
    private void saddlerecipe$applyBounce(MovementType type, Vec3d movement, CallbackInfo ci) {
        if (Double.isNaN(saddlerecipe$bounce)) return;
        Entity self = (Entity) (Object) this;
        Vec3d v = self.getVelocity();
        self.setVelocity(v.x, saddlerecipe$bounce, v.z);
        self.velocityModified = true;
        saddlerecipe$bounce = Double.NaN;
    }

    @Inject(method = "getVelocityMultiplier", at = @At("RETURN"), cancellable = true, require = 0)
    private void saddlerecipe$honeySlow(CallbackInfoReturnable<Float> cir) {
        if (saddlerecipe$under(BlockMarks.HONEY)) cir.setReturnValue(Math.min(cir.getReturnValue(), 0.4F));
    }

    @Inject(method = "getJumpVelocityMultiplier", at = @At("RETURN"), cancellable = true, require = 0)
    private void saddlerecipe$honeyJump(CallbackInfoReturnable<Float> cir) {
        if (saddlerecipe$under(BlockMarks.HONEY)) cir.setReturnValue(Math.min(cir.getReturnValue(), 0.5F));
    }

    @Unique
    private boolean saddlerecipe$under(int flag) {
        Entity self = (Entity) (Object) this;
        BlockPos below = BlockPos.ofFloored(self.getX(), self.getBoundingBox().minY - 0.500001, self.getZ());
        return (saddlerecipe$props & flag) != 0 || BlockMarks.has(self.getWorld(), below, flag);
    }
}
