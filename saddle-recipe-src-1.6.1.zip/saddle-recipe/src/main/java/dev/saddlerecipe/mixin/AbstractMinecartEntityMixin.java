package dev.saddlerecipe.mixin;

import dev.saddlerecipe.AmethystJumper;
import net.minecraft.block.AbstractRailBlock;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.vehicle.AbstractMinecartEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Пока вагонетка "в прыжке", tick() считает, что под ней нет рельса, и использует
 * свободный полёт (moveOffRail). Иначе рельс в пределах 1 блока снова "прилепил" бы её вниз.
 */
@Mixin(AbstractMinecartEntity.class)
public abstract class AbstractMinecartEntityMixin implements AmethystJumper {
    @Unique private int amethyst$airTicks;
    @Unique private boolean amethyst$jumping;

    @Inject(method = "tick", at = @At("HEAD"))
    private void amethyst$tickJump(CallbackInfo ci) {
        if (amethyst$airTicks > 0) {
            amethyst$airTicks--;
        } else if (amethyst$jumping && ((Entity) (Object) this).isOnGround()) {
            amethyst$jumping = false; // приземлилась — дальше обычная езда по рельсам
        }
    }

    @Redirect(method = "tick",
              at = @At(value = "INVOKE",
                       target = "Lnet/minecraft/block/AbstractRailBlock;isRail(Lnet/minecraft/block/BlockState;)Z"))
    private boolean amethyst$skipRailWhileJumping(BlockState state) {
        return !amethyst$jumping && AbstractRailBlock.isRail(state);
    }

    @Override public boolean amethyst$isJumping() { return amethyst$jumping; }

    @Override public void amethyst$launch(int minAirTicks) {
        amethyst$jumping = true;
        amethyst$airTicks = minAirTicks;
    }
}
