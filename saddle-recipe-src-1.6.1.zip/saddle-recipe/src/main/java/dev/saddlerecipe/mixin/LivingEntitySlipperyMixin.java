package dev.saddlerecipe.mixin;

import dev.saddlerecipe.BlockMarks;
import dev.saddlerecipe.MarkedEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.block.Block;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/** Скользкий как лёд: подменяем скользкость блока под ногами в travel(). */
@Mixin(LivingEntity.class)
public abstract class LivingEntitySlipperyMixin {
    @Redirect(method = "travel",
              at = @At(value = "INVOKE", target = "Lnet/minecraft/block/Block;getSlipperiness()F"),
              require = 0)
    private float saddlerecipe$iceSlip(Block block) {
        float base = block.getSlipperiness();
        LivingEntity self = (LivingEntity) (Object) this;
        BlockPos below = BlockPos.ofFloored(self.getX(), self.getBoundingBox().minY - 0.500001, self.getZ());
        boolean ice = (((MarkedEntity) self).saddlerecipe$getProps() & BlockMarks.ICE) != 0
                || BlockMarks.has(self.getWorld(), below, BlockMarks.ICE);
        return ice ? Math.max(base, 0.98F) : base;
    }

    /** Взрывной моб взрывается при смерти. */
    @Inject(method = "onDeath", at = @At("HEAD"), require = 0)
    private void saddlerecipe$explodeOnDeath(DamageSource source, CallbackInfo ci) {
        LivingEntity self = (LivingEntity) (Object) this;
        MarkedEntity m = (MarkedEntity) self;
        if (self.getWorld().isClient || (m.saddlerecipe$getProps() & BlockMarks.TNT) == 0) return;
        m.saddlerecipe$setProps(m.saddlerecipe$getProps() & ~BlockMarks.TNT);
        self.getWorld().createExplosion(self, self.getX(), self.getBodyY(0.5), self.getZ(),
                2.5F, World.ExplosionSourceType.TNT);
    }
}
