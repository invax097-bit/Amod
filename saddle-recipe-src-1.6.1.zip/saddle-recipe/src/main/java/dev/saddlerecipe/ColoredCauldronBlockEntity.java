package dev.saddlerecipe;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.util.math.BlockPos;

/** Remembers which flowers were mixed into the cauldron (max 3, a 4th spoils it). */
public class ColoredCauldronBlockEntity extends BlockEntity {
    public static final int MAX_INGREDIENTS = 3;
    public static final int WATER_COLOR = 0x3F76E4;
    public static final int SPOILED_COLOR = 0x5B4B2E;

    private final List<FlowerMix> mix = new ArrayList<>();
    private boolean spoiled;

    public ColoredCauldronBlockEntity(BlockPos pos, BlockState state) {
        super(SaddleRecipeMod.COLORED_CAULDRON_BE, pos, state);
    }

    public List<FlowerMix> getMix() { return mix; }
    public boolean isSpoiled() { return spoiled; }

    /** Can this ingredient still be added (not spoiled, not already in the mix)? */
    public boolean canAdd(FlowerMix ingredient) {
        return !spoiled && !mix.contains(ingredient);
    }

    /** Adds an ingredient; a 4th different one spoils the water. */
    public void add(FlowerMix ingredient) {
        if (!canAdd(ingredient)) return;
        if (mix.size() >= MAX_INGREDIENTS) {
            spoiled = true;
        } else {
            mix.add(ingredient);
        }
        sync();
    }

    public int getColor() {
        if (spoiled) return SPOILED_COLOR;
        if (mix.isEmpty()) return WATER_COLOR;
        int r = 0, g = 0, b = 0;
        for (FlowerMix m : mix) {
            int rgb = m.rgb();
            r += (rgb >> 16) & 0xFF;
            g += (rgb >> 8) & 0xFF;
            b += rgb & 0xFF;
        }
        int n = mix.size();
        return ((r / n) << 16) | ((g / n) << 8) | (b / n);
    }

    private void sync() {
        markDirty();
        if (world != null) {
            world.updateListeners(pos, getCachedState(), getCachedState(), Block.NOTIFY_ALL);
        }
    }

    @Override
    protected void writeNbt(NbtCompound nbt) {
        super.writeNbt(nbt);
        StringBuilder sb = new StringBuilder();
        for (FlowerMix m : mix) {
            if (sb.length() > 0) sb.append(',');
            sb.append(m.name());
        }
        nbt.putString("Mix", sb.toString());
        nbt.putBoolean("Spoiled", spoiled);
    }

    @Override
    public void readNbt(NbtCompound nbt) {
        super.readNbt(nbt);
        mix.clear();
        String raw = nbt.getString("Mix");
        if (!raw.isEmpty()) {
            for (String part : raw.split(",")) {
                try {
                    mix.add(FlowerMix.valueOf(part));
                } catch (IllegalArgumentException ignored) {
                    // unknown entry from another version: skip
                }
            }
        }
        spoiled = nbt.getBoolean("Spoiled");
        // Client: make the tinted water redraw with the new colour.
        if (world != null && world.isClient) {
            world.updateListeners(pos, getCachedState(), getCachedState(), Block.REDRAW_ON_MAIN_THREAD);
        }
    }

    @Override
    public Packet<ClientPlayPacketListener> toUpdatePacket() {
        return BlockEntityUpdateS2CPacket.create(this);
    }

    @Override
    public NbtCompound toInitialChunkDataNbt() {
        return createNbt();
    }
}
