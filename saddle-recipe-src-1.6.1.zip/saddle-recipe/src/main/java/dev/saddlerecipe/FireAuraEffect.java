package dev.saddlerecipe;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.util.math.Box;

/**
 * Ignition: mobs that touch you catch fire, and you take no fire damage
 * (the immunity itself lives in LivingEntityMixin).
 */
public class FireAuraEffect extends StatusEffect {
    public FireAuraEffect() {
        super(StatusEffectCategory.BENEFICIAL, 0xFF6A00);
    }

    @Override
    public boolean canApplyUpdateEffect(int duration, int amplifier) {
        return true;
    }

    @Override
    public void applyUpdateEffect(LivingEntity entity, int amplifier) {
        if (entity.getWorld().isClient) return;
        entity.extinguish();

        // Anything whose hitbox touches ours.
        Box touch = entity.getBoundingBox().expand(0.25);
        for (MobEntity mob : entity.getWorld().getEntitiesByClass(MobEntity.class, touch,
                m -> m != entity && m.isAlive() && !m.isFireImmune()
                        && !(m instanceof TameableEntity t && t.isTamed()))) {
            mob.setOnFireFor(4);
        }
    }
}
