package dev.saddlerecipe;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.render.RenderLayer;
import java.util.HashMap;
import java.util.Map;

public class SaddleRecipeClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BlockRenderLayerMap.INSTANCE.putBlock(SaddleRecipeMod.COLORED_WATER_CAULDRON, RenderLayer.getCutout());
        BlockRenderLayerMap.INSTANCE.putBlock(AmethystRails.AMETHYST_RAIL, RenderLayer.getCutout());
        // The vanilla water_cauldron_* models tint the water surface (tintindex 0).
        ColorProviderRegistry.BLOCK.register((state, world, pos, tintIndex) -> {
            if (world != null && pos != null
                    && world.getBlockEntity(pos) instanceof ColoredCauldronBlockEntity be) {
                return be.getColor();
            }
            return ColoredCauldronBlockEntity.WATER_COLOR;
        }, SaddleRecipeMod.COLORED_WATER_CAULDRON);

        // Метки блоков от Палки бесконечности (для предсказания движения на клиенте).
        ClientPlayNetworking.registerGlobalReceiver(BlockMarks.PACKET_FULL, (client, handler, buf, sender) -> {
            int n = buf.readInt();
            Map<Long, Integer> all = new HashMap<>();
            for (int i = 0; i < n; i++) all.put(buf.readLong(), buf.readInt());
            client.execute(() -> BlockMarks.clientSetAll(all));
        });
        ClientPlayNetworking.registerGlobalReceiver(BlockMarks.PACKET_SET, (client, handler, buf, sender) -> {
            long pos = buf.readLong();
            int props = buf.readInt();
            client.execute(() -> BlockMarks.clientSet(pos, props));
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> BlockMarks.clientClear());
    }
}
