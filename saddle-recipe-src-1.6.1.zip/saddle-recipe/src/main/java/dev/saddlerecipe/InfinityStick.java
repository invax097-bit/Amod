package dev.saddlerecipe;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;

public final class InfinityStick {
    public static final Identifier ID = new Identifier(SaddleRecipeMod.MOD_ID, "infinity_stick");
    public static Item INFINITY_STICK;

    private InfinityStick() {}

    public static void register() {
        INFINITY_STICK = Registry.register(Registries.ITEM, ID,
                new InfinityStickItem(new Item.Settings().maxCount(1).rarity(Rarity.EPIC)));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> e.add(INFINITY_STICK));

        ServerTickEvents.END_WORLD_TICK.register(BlockMarks::tickWorld);

        // Клиенту нужны метки для предсказания движения.
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> BlockMarks.sendFull(handler.player));
        ServerEntityWorldChangeEvents.AFTER_PLAYER_CHANGE_WORLD.register((player, origin, destination) -> BlockMarks.sendFull(player));
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> BlockMarks.sendFull(newPlayer));

        // Блок-«динамит» поджигается огнивом / огненным шаром.
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (player.isSpectator()) return ActionResult.PASS;
            ItemStack stack = player.getStackInHand(hand);
            boolean flint = stack.isOf(Items.FLINT_AND_STEEL);
            if (!flint && !stack.isOf(Items.FIRE_CHARGE)) return ActionResult.PASS;
            if (!BlockMarks.has(world, hit.getBlockPos(), BlockMarks.TNT)) return ActionResult.PASS;
            if (world instanceof ServerWorld sw) {
                BlockMarks.ignite(sw, hit.getBlockPos(), player);
                if (flint) stack.damage(1, player, p -> p.sendToolBreakStatus(hand));
                else if (!player.isCreative()) stack.decrement(1);
            }
            return ActionResult.success(world.isClient);
        });
    }
}
