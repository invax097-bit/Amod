package dev.saddlerecipe;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.PoweredRailBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.vehicle.AbstractMinecartEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Аметистовые рельсы: как энергорельсы (разгон при подаче питания),
 * но дополнительно подбрасывают вагонетку вверх.
 *
 * Ванильный разгон прошит в AbstractMinecartEntity только для Blocks.POWERED_RAIL,
 * поэтому разгон здесь сделан вручную в onEntityCollision.
 */
public class AmethystRailBlock extends PoweredRailBlock {
    /** Как у ванильных энергорельсов. */
    public static final double BOOST = 0.06;
    /** Вертикальная скорость прыжка (~2 блока). Меняй под вкус. */
    public static final double JUMP_VELOCITY = 0.42;
    public static final double MIN_SPEED = 0.05;

    public AmethystRailBlock(AbstractBlock.Settings settings) {
        super(settings);
    }

    @Override
    public void onEntityCollision(BlockState state, World world, BlockPos pos, Entity entity) {
        if (world.isClient || !(entity instanceof AbstractMinecartEntity cart)) return;
        if (!state.get(POWERED)) return;

        Vec3d v = cart.getVelocity();
        double speed = Math.sqrt(v.x * v.x + v.z * v.z);
        if (speed < MIN_SPEED) return;

        AmethystJumper jumper = (AmethystJumper) cart;
        if (jumper.amethyst$isJumping()) return;

        cart.setVelocity(v.x + v.x / speed * BOOST, JUMP_VELOCITY, v.z + v.z / speed * BOOST);
        cart.velocityModified = true;
        jumper.amethyst$launch(4);
    }
}
