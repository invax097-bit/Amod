package dev.saddlerecipe;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.Block;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.TntEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.PersistentState;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;
import org.jetbrains.annotations.Nullable;

/**
 * "Свойства" блоков, выданные Палкой бесконечности. Хранятся по миру (на сервере — в PersistentState),
 * клиенту рассылаются пакетами, чтобы движение предсказывалось одинаково.
 */
public final class BlockMarks {
    public static final int TNT = 1;
    public static final int SLIME = 2;
    public static final int HONEY = 4;
    public static final int ICE = 8;

    public static final Identifier PACKET_FULL = new Identifier(SaddleRecipeMod.MOD_ID, "marks_full");
    public static final Identifier PACKET_SET = new Identifier(SaddleRecipeMod.MOD_ID, "mark_set");

    /** Клиентская копия меток текущего мира. */
    private static final Map<Long, Integer> CLIENT = new HashMap<>();

    private BlockMarks() {}

    // ---------- чтение ----------

    public static int get(World world, BlockPos pos) {
        if (world.isClient) {
            return CLIENT.isEmpty() ? 0 : CLIENT.getOrDefault(pos.asLong(), 0);
        }
        if (!(world instanceof ServerWorld sw)) return 0;
        MarkState s = state(sw);
        if (s.map.isEmpty()) return 0;
        Entry e = s.map.get(pos.asLong());
        if (e == null) return 0;
        if (sw.getBlockState(pos).getBlock() != e.block) { // блок заменили/сломали — метка устарела
            setProps(sw, pos, 0);
            return 0;
        }
        return e.props;
    }

    public static boolean has(World world, BlockPos pos, int flag) {
        return (get(world, pos) & flag) != 0;
    }

    // ---------- запись (сервер) ----------

    public static void setProps(ServerWorld world, BlockPos pos, int props) {
        MarkState s = state(world);
        if (props == 0) {
            if (s.map.remove(pos.asLong()) == null) return;
        } else {
            s.map.put(pos.asLong(), new Entry(props, world.getBlockState(pos).getBlock()));
        }
        s.markDirty();
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeLong(pos.asLong());
        buf.writeInt(props);
        for (ServerPlayerEntity p : world.getPlayers()) {
            ServerPlayNetworking.send(p, PACKET_SET, PacketByteBufs.copy(buf));
        }
    }

    public static void sendFull(ServerPlayerEntity player) {
        ServerWorld world = player.getServerWorld();
        MarkState s = state(world);
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(s.map.size());
        for (Map.Entry<Long, Entry> e : s.map.entrySet()) {
            buf.writeLong(e.getKey());
            buf.writeInt(e.getValue().props);
        }
        ServerPlayNetworking.send(player, PACKET_FULL, buf);
    }

    // ---------- клиент ----------

    public static void clientSetAll(Map<Long, Integer> all) {
        CLIENT.clear();
        CLIENT.putAll(all);
    }

    public static void clientSet(long pos, int props) {
        if (props == 0) CLIENT.remove(pos); else CLIENT.put(pos, props);
    }

    public static void clientClear() { CLIENT.clear(); }

    // ---------- динамит ----------

    public static void ignite(ServerWorld world, BlockPos pos, @Nullable LivingEntity igniter) {
        setProps(world, pos, 0);
        world.removeBlock(pos, false);
        TntEntity tnt = new TntEntity(world, pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, igniter);
        world.spawnEntity(tnt);
        world.playSound(null, tnt.getX(), tnt.getY(), tnt.getZ(),
                SoundEvents.ENTITY_TNT_PRIMED, SoundCategory.BLOCKS, 1.0F, 1.0F);
        world.emitGameEvent(igniter, GameEvent.PRIME_FUSE, pos);
    }

    /** Раз в несколько тиков: чистит устаревшие метки и поджигает «динамит» от редстоуна/огня. */
    public static void tickWorld(ServerWorld world) {
        if (world.getTime() % 5 != 0) return;
        MarkState s = state(world);
        if (s.map.isEmpty()) return;
        List<Long> keys = new ArrayList<>(s.map.keySet());
        for (long key : keys) {
            Entry e = s.map.get(key);
            if (e == null) continue;
            BlockPos pos = BlockPos.fromLong(key);
            if (!world.isChunkLoaded(pos)) continue;
            if (world.getBlockState(pos).getBlock() != e.block) {
                setProps(world, pos, 0);
                continue;
            }
            if ((e.props & TNT) != 0 && (world.isReceivingRedstonePower(pos) || nextToFire(world, pos))) {
                ignite(world, pos, null);
            }
        }
    }

    private static boolean nextToFire(ServerWorld world, BlockPos pos) {
        for (net.minecraft.util.math.Direction d : net.minecraft.util.math.Direction.values()) {
            if (world.getBlockState(pos.offset(d)).isIn(net.minecraft.registry.tag.BlockTags.FIRE)) return true;
        }
        return false;
    }

    // ---------- хранилище ----------

    private static MarkState state(ServerWorld world) {
        return world.getPersistentStateManager().getOrCreate(MarkState::fromNbt, MarkState::new, "saddlerecipe_marks");
    }

    private record Entry(int props, Block block) {}

    public static final class MarkState extends PersistentState {
        final Map<Long, Entry> map = new HashMap<>();

        public static MarkState fromNbt(NbtCompound nbt) {
            MarkState s = new MarkState();
            NbtList list = nbt.getList("Marks", NbtElement.COMPOUND_TYPE);
            for (int i = 0; i < list.size(); i++) {
                NbtCompound c = list.getCompound(i);
                Identifier id = Identifier.tryParse(c.getString("Block"));
                if (id == null || !Registries.BLOCK.containsId(id)) continue;
                s.map.put(c.getLong("Pos"), new Entry(c.getInt("Props"), Registries.BLOCK.get(id)));
            }
            return s;
        }

        @Override
        public NbtCompound writeNbt(NbtCompound nbt) {
            NbtList list = new NbtList();
            for (Map.Entry<Long, Entry> e : map.entrySet()) {
                NbtCompound c = new NbtCompound();
                c.putLong("Pos", e.getKey());
                c.putInt("Props", e.getValue().props);
                c.putString("Block", Registries.BLOCK.getId(e.getValue().block).toString());
                list.add(c);
            }
            nbt.put("Marks", list);
            return nbt;
        }
    }
}
