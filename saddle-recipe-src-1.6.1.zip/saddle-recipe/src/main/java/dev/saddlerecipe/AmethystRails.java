package dev.saddlerecipe;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class AmethystRails {
    public static final Identifier ID = new Identifier("saddlerecipe", "amethyst_rail");
    public static final Block AMETHYST_RAIL =
            new AmethystRailBlock(AbstractBlock.Settings.copy(Blocks.POWERED_RAIL));

    private AmethystRails() {}

    /** Вызвать из SaddleRecipeMod.onInitialize(). */
    public static void register() {
        Registry.register(Registries.BLOCK, ID, AMETHYST_RAIL);
        Registry.register(Registries.ITEM, ID, new BlockItem(AMETHYST_RAIL, new FabricItemSettings()));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.REDSTONE)
                .register(e -> e.addAfter(Items.POWERED_RAIL, AMETHYST_RAIL));
    }
}
