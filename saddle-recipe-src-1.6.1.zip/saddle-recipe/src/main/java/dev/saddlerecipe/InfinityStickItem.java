package dev.saddlerecipe;

import java.util.List;

import net.minecraft.block.BlockState;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * Палка бесконечности.
 *  ПКМ по блоку        — применить выбранное свойство к блоку.
 *  Shift+ПКМ (или в воздух) — переключить режим.
 */
public class InfinityStickItem extends Item {
    public enum Mode {
        TNT(BlockMarks.TNT), SLIME(BlockMarks.SLIME), HONEY(BlockMarks.HONEY), ICE(BlockMarks.ICE), CLEAR(0);

        public final int flag;
        Mode(int flag) { this.flag = flag; }
        public String key() { return name().toLowerCase(); }
        public Mode next() { return values()[(ordinal() + 1) % values().length]; }
    }

    public InfinityStickItem(Settings settings) {
        super(settings);
    }

    public static Mode getMode(ItemStack stack) {
        int i = stack.hasNbt() ? stack.getNbt().getInt("Mode") : 0;
        Mode[] all = Mode.values();
        return all[Math.floorMod(i, all.length)];
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return true;
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext ctx) {
        World world = ctx.getWorld();
        PlayerEntity player = ctx.getPlayer();
        ItemStack stack = ctx.getStack();
        if (player != null && player.isSneaking()) {
            if (!world.isClient) cycle(stack, player);
            return ActionResult.success(world.isClient);
        }
        BlockPos pos = ctx.getBlockPos();
        BlockState bs = world.getBlockState(pos);
        if (bs.isAir()) return ActionResult.PASS;
        if (world.isClient) return ActionResult.SUCCESS;

        ServerWorld sw = (ServerWorld) world;
        Mode mode = getMode(stack);
        int current = BlockMarks.get(sw, pos);
        int next = mode == Mode.CLEAR ? 0 : (current | mode.flag);
        BlockMarks.setProps(sw, pos, next);

        sw.playSound(null, pos, SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.BLOCKS, 1.0F, 1.0F);
        sw.spawnParticles(mode == Mode.CLEAR ? ParticleTypes.SMOKE : ParticleTypes.ENCHANT,
                pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, 12, 0.4, 0.3, 0.4, 0.1);
        if (player instanceof ServerPlayerEntity sp) {
            sp.sendMessage(Text.translatable("item.saddlerecipe.infinity_stick.applied." + mode.key())
                    .formatted(Formatting.LIGHT_PURPLE), true);
        }
        return ActionResult.SUCCESS;
    }

    /** ПКМ по мобу: то же самое, но свойства получает существо (игроки не поддерживаются). */
    @Override
    public ActionResult useOnEntity(ItemStack stack, PlayerEntity user, LivingEntity target, Hand hand) {
        World world = user.getWorld();
        if (user.isSneaking()) {
            if (!world.isClient) cycle(stack, user);
            return ActionResult.success(world.isClient);
        }
        if (target instanceof PlayerEntity) return ActionResult.PASS;
        if (world.isClient) return ActionResult.SUCCESS;
        Mode mode = getMode(stack);
        MarkedEntity m = (MarkedEntity) target;
        m.saddlerecipe$setProps(mode == Mode.CLEAR ? 0 : (m.saddlerecipe$getProps() | mode.flag));
        ((ServerWorld) world).spawnParticles(mode == Mode.CLEAR ? ParticleTypes.SMOKE : ParticleTypes.ENCHANT,
                target.getX(), target.getBodyY(0.5), target.getZ(), 15, 0.4, 0.4, 0.4, 0.1);
        world.playSound(null, target.getBlockPos(), SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.BLOCKS, 1.0F, 1.0F);
        if (user instanceof ServerPlayerEntity sp) {
            sp.sendMessage(Text.translatable("item.saddlerecipe.infinity_stick.applied." + mode.key())
                    .formatted(Formatting.LIGHT_PURPLE), true);
        }
        return ActionResult.SUCCESS;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (!world.isClient) cycle(stack, player);
        return TypedActionResult.success(stack, world.isClient);
    }

    private static void cycle(ItemStack stack, PlayerEntity player) {
        Mode next = getMode(stack).next();
        stack.getOrCreateNbt().putInt("Mode", next.ordinal());
        if (player instanceof ServerPlayerEntity sp) {
            sp.sendMessage(Text.translatable("item.saddlerecipe.infinity_stick.mode",
                    Text.translatable("item.saddlerecipe.infinity_stick.mode." + next.key()))
                    .formatted(Formatting.AQUA), true);
        }
    }

    @Override
    public void appendTooltip(ItemStack stack, @Nullable World world, List<Text> tooltip, TooltipContext context) {
        tooltip.add(Text.translatable("item.saddlerecipe.infinity_stick.mode",
                Text.translatable("item.saddlerecipe.infinity_stick.mode." + getMode(stack).key()))
                .formatted(Formatting.AQUA));
        tooltip.add(Text.translatable("item.saddlerecipe.infinity_stick.hint").formatted(Formatting.GRAY));
    }
}
