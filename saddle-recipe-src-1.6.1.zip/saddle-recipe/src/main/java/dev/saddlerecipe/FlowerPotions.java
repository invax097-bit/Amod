package dev.saddlerecipe;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.block.BlockState;
import net.minecraft.block.LeveledCauldronBlock;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsage;
import net.minecraft.item.Items;
import net.minecraft.potion.PotionUtil;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;

/** Weak, short potions: one effect per mixed colour; a spoiled mix gives a bad potion. */
public final class FlowerPotions {
    /** 12 seconds. */
    public static final int DURATION = 12 * 20;

    private FlowerPotions() {}

    public static ItemStack create(ColoredCauldronBlockEntity be) {
        List<StatusEffectInstance> effects = new ArrayList<>();
        MutableText name;
        if (be.isSpoiled()) {
            effects.add(new StatusEffectInstance(StatusEffects.NAUSEA, DURATION, 0));
            effects.add(new StatusEffectInstance(StatusEffects.HUNGER, DURATION, 0));
            name = Text.translatable("item.saddlerecipe.flower_potion.spoiled");
        } else {
            // "Minor Potion of Speed and Strength" - effect names in the order the flowers were added.
            name = Text.translatable("item.saddlerecipe.flower_potion.prefix").append(" ");
            List<FlowerMix> ingredients = be.getMix();
            for (int i = 0; i < ingredients.size(); i++) {
                FlowerMix m = ingredients.get(i);
                effects.add(new StatusEffectInstance(m.effect(), DURATION, 0));
                if (i > 0) {
                    if (i == ingredients.size() - 1) {
                        name.append(" ").append(Text.translatable("item.saddlerecipe.flower_potion.and")).append(" ");
                    } else {
                        name.append(", ");
                    }
                }
                name.append(Text.translatable("item.saddlerecipe.flower_potion.effect." + m.key()));
            }
        }

        ItemStack stack = new ItemStack(Items.POTION);
        PotionUtil.setCustomPotionEffects(stack, effects);
        stack.getOrCreateNbt().putInt("CustomPotionColor", be.getColor());
        stack.setCustomName(name.styled(st -> st.withItalic(false)));
        return stack;
    }

    /** CauldronBehavior for an empty glass bottle used on a flower cauldron. */
    public static ActionResult fillBottle(BlockState state, World world, BlockPos pos, PlayerEntity player,
                                          Hand hand, ItemStack stack) {
        if (!(world.getBlockEntity(pos) instanceof ColoredCauldronBlockEntity be)) return ActionResult.PASS;
        if (!world.isClient) {
            ItemStack potion = create(be);
            player.setStackInHand(hand, ItemUsage.exchangeStack(stack, player, potion));
            player.incrementStat(Stats.USE_CAULDRON);
            player.incrementStat(Stats.USED.getOrCreateStat(stack.getItem()));
            LeveledCauldronBlock.decrementFluidLevel(state, world, pos);
            world.playSound(null, pos, SoundEvents.ITEM_BOTTLE_FILL, SoundCategory.BLOCKS, 1.0f, 1.0f);
            world.emitGameEvent(null, GameEvent.FLUID_PICKUP, pos);
        }
        return ActionResult.success(world.isClient);
    }
}
