package dev.saddlerecipe;

/** Свойства Палки бесконечности, выданные самому существу (реализуется миксином в Entity). */
public interface MarkedEntity {
    int saddlerecipe$getProps();
    void saddlerecipe$setProps(int props);
}
