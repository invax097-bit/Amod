package dev.saddlerecipe;

import java.util.Map;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BlockState;
import net.minecraft.block.LeveledCauldronBlock;
import net.minecraft.block.cauldron.CauldronBehavior;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;
import net.minecraft.world.biome.Biome;

/** Water cauldron holding a flower mix (stored in a block entity). */
public class ColoredWaterCauldronBlock extends LeveledCauldronBlock implements BlockEntityProvider {

    public ColoredWaterCauldronBlock(AbstractBlock.Settings settings) {
        super(settings, precipitation -> precipitation == Biome.Precipitation.RAIN, createBehaviors());
        setDefaultState(getDefaultState().with(LEVEL, 1));
    }

    /** Water behaviours, but an empty bottle yields a flower potion. */
    private static Map<Item, CauldronBehavior> createBehaviors() {
        Map<Item, CauldronBehavior> map = CauldronBehavior.createMap();
        map.putAll(CauldronBehavior.WATER_CAULDRON_BEHAVIOR);
        map.put(Items.GLASS_BOTTLE, FlowerPotions::fillBottle);
        return map;
    }

    @Override
    public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
        return new ColoredCauldronBlockEntity(pos, state);
    }

    @Override
    public ItemStack getPickStack(BlockView world, BlockPos pos, BlockState state) {
        return new ItemStack(Items.CAULDRON);
    }
}
