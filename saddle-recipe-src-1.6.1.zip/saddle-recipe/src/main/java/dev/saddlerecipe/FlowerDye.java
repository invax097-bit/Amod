package dev.saddlerecipe;

import java.util.HashMap;
import java.util.Map;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.LeveledCauldronBlock;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public final class FlowerDye {
    private static final Map<Item, FlowerMix> COLORS = new HashMap<>();

    static {
        COLORS.put(Items.POPPY, FlowerMix.RED);
        COLORS.put(Items.DANDELION, FlowerMix.YELLOW);
        COLORS.put(Items.BLUE_ORCHID, FlowerMix.LIGHT_BLUE);
        COLORS.put(Items.ALLIUM, FlowerMix.MAGENTA);
        COLORS.put(Items.AZURE_BLUET, FlowerMix.LIGHT_GRAY);
        COLORS.put(Items.RED_TULIP, FlowerMix.RED);
        COLORS.put(Items.ORANGE_TULIP, FlowerMix.ORANGE);
        COLORS.put(Items.WHITE_TULIP, FlowerMix.WHITE);
        COLORS.put(Items.PINK_TULIP, FlowerMix.PINK);
        COLORS.put(Items.OXEYE_DAISY, FlowerMix.WHITE);
        COLORS.put(Items.CORNFLOWER, FlowerMix.BLUE);
        COLORS.put(Items.LILY_OF_THE_VALLEY, FlowerMix.WHITE);
        COLORS.put(Items.WITHER_ROSE, FlowerMix.BLACK);
        COLORS.put(Items.TORCHFLOWER, FlowerMix.TORCHFLOWER);
        COLORS.put(Items.PITCHER_PLANT, FlowerMix.CYAN);
        COLORS.put(Items.SUNFLOWER, FlowerMix.YELLOW);
        COLORS.put(Items.LILAC, FlowerMix.MAGENTA);
        COLORS.put(Items.ROSE_BUSH, FlowerMix.RED);
        COLORS.put(Items.PEONY, FlowerMix.PINK);
    }

    private FlowerDye() {}

    public static boolean isFlower(ItemStack stack) {
        return stack.isIn(ItemTags.SMALL_FLOWERS) || stack.isIn(ItemTags.TALL_FLOWERS);
    }

    public static FlowerMix mixOf(ItemStack stack) {
        FlowerMix known = COLORS.get(stack.getItem());
        if (known != null) return known;
        // Modded / unknown flower: stable ingredient derived from its id (never the special torchflower one).
        int h = Registries.ITEM.getId(stack.getItem()).hashCode();
        return FlowerMix.values()[Math.floorMod(h, FlowerMix.PLAIN_COUNT)];
    }

    /** Would this flower change the cauldron at pos? (Same colour, or an already spoiled mix, changes nothing.) */
    public static boolean canMix(World world, BlockPos pos, ItemStack flower) {
        if (!isFlower(flower)) return false;
        BlockState state = world.getBlockState(pos);
        if (state.isOf(Blocks.WATER_CAULDRON)) return true;
        if (state.isOf(SaddleRecipeMod.COLORED_WATER_CAULDRON)
                && world.getBlockEntity(pos) instanceof ColoredCauldronBlockEntity be) {
            return be.canAdd(mixOf(flower));
        }
        return false;
    }

    /** Mixes the flower into the cauldron. Does NOT consume it. Returns true if the water changed. */
    public static boolean mix(World world, BlockPos pos, ItemStack flower) {
        if (!canMix(world, pos, flower)) return false;
        FlowerMix ingredient = mixOf(flower);
        BlockState state = world.getBlockState(pos);

        if (state.isOf(Blocks.WATER_CAULDRON)) {
            world.setBlockState(pos, SaddleRecipeMod.COLORED_WATER_CAULDRON.getDefaultState()
                    .with(LeveledCauldronBlock.LEVEL, state.get(LeveledCauldronBlock.LEVEL)));
        }
        if (world.getBlockEntity(pos) instanceof ColoredCauldronBlockEntity be) {
            be.add(ingredient);
        }

        world.playSound(null, pos, SoundEvents.ENTITY_GENERIC_SPLASH, SoundCategory.BLOCKS, 0.4f, 1.2f);
        if (world instanceof ServerWorld sw) {
            sw.spawnParticles(ParticleTypes.SPLASH, pos.getX() + 0.5, pos.getY() + 0.9, pos.getZ() + 0.5,
                    8, 0.2, 0.05, 0.2, 0.0);
        }
        return true;
    }
}
