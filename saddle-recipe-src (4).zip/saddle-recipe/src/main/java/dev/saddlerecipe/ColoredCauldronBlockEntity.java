package dev.saddlerecipe;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.util.DyeColor;
import net.minecraft.util.math.BlockPos;

/** Remembers which flower colours were mixed into the cauldron (max 3, a 4th spoils it). */
public class ColoredCauldronBlockEntity extends BlockEntity {
    public static final int MAX_COLORS = 3;
    public static final int WATER_COLOR = 0x3F76E4;
    public static final int SPOILED_COLOR = 0x5B4B2E;

    private final List<DyeColor> colors = new ArrayList<>();
    private boolean spoiled;

    public ColoredCauldronBlockEntity(BlockPos pos, BlockState state) {
        super(SaddleRecipeMod.COLORED_CAULDRON_BE, pos, state);
    }

    public List<DyeColor> getColors() { return colors; }
    public boolean isSpoiled() { return spoiled; }

    /** Can this colour still be added (not spoiled, not already in the mix)? */
    public boolean canAdd(DyeColor color) {
        return !spoiled && !colors.contains(color);
    }

    /** Adds a colour; a 4th different colour spoils the water. */
    public void addColor(DyeColor color) {
        if (spoiled || colors.contains(color)) return;
        if (colors.size() >= MAX_COLORS) {
            spoiled = true;
        } else {
            colors.add(color);
        }
        sync();
    }

    public int getColor() {
        if (spoiled) return SPOILED_COLOR;
        if (colors.isEmpty()) return WATER_COLOR;
        int r = 0, g = 0, b = 0;
        for (DyeColor c : colors) {
            int rgb = c.getFireworkColor();
            r += (rgb >> 16) & 0xFF;
            g += (rgb >> 8) & 0xFF;
            b += rgb & 0xFF;
        }
        int n = colors.size();
        return ((r / n) << 16) | ((g / n) << 8) | (b / n);
    }

    private void sync() {
        markDirty();
        if (world != null) {
            world.updateListeners(pos, getCachedState(), getCachedState(), Block.NOTIFY_ALL);
        }
    }

    @Override
    protected void writeNbt(NbtCompound nbt) {
        super.writeNbt(nbt);
        int[] ids = new int[colors.size()];
        for (int i = 0; i < ids.length; i++) ids[i] = colors.get(i).getId();
        nbt.putIntArray("Colors", ids);
        nbt.putBoolean("Spoiled", spoiled);
    }

    @Override
    public void readNbt(NbtCompound nbt) {
        super.readNbt(nbt);
        colors.clear();
        for (int id : nbt.getIntArray("Colors")) colors.add(DyeColor.byId(id));
        spoiled = nbt.getBoolean("Spoiled");
        // Client: make the tinted water redraw with the new colour.
        if (world != null && world.isClient) {
            world.updateListeners(pos, getCachedState(), getCachedState(), Block.REDRAW_ON_MAIN_THREAD);
        }
    }

    @Override
    public Packet<ClientPlayPacketListener> toUpdatePacket() {
        return BlockEntityUpdateS2CPacket.create(this);
    }

    @Override
    public NbtCompound toInitialChunkDataNbt() {
        return createNbt();
    }
}
